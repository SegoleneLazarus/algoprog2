INSTALL
=======

To run these exercices, please install Qt development toolkit and QtCreator IDE


Windows
-------

 * https://download.qt.io/archive/qt/4.8/4.8.7/qt-opensource-windows-x86-mingw482-4.8.7.exe
 * https://download.qt.io/archive/qtcreator/4.4/4.4.1/qt-creator-opensource-windows-x86_64-4.4.1.exe

Linux
-----

```bash
sudo apt-get install qt5-default qtcreator
```
